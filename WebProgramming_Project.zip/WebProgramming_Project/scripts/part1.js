/**
 * Author: Maisha Maimuna
 * Target: enquire.html
 * Purpose: Load data from session storage and submit to server
 */
"use strict";


function validateForm() {
  let x = document.forms["myForm"]["fname"].value;
  if (x == "") {
    alert("Name must be filled out");
    return false;
  }
  let x = document.forms["myForm"]["email"].value;
  if (x == "") {
    alert("Email must be filled out");
    return false;
  }
  let x = document.forms["myForm"]["adr"].value;
  if (x == "") {
    alert("Name must be filled out");
    return false;
  }
  let x = document.forms["myForm"]["city"].value;
  if (x == "") {
    alert("Name must be filled out");
    return false;
  }
  let x = document.forms["myForm"]["state"].value;
  if (x == "") {
    alert("Name must be filled out");
    return false;
  }
  let x = document.forms["myForm"]["zip"].value;
  if (x == "") {
    alert("Name must be filled out");
    return false;
  }
  let x = document.forms["myForm"]["productService"].value;
  if (x == "") {
    alert("Name must be filled out");
    return false;
  }
}



function storeData(fname, email, adr, city, state, zip, cruise ) {

 

    sessionStorage.fname = fname;   
    sessionStorage.email = email;
    sessionStorage.adr = adr;
    sessionStorage.city = city;
    sessionStorage.state = state;
    sessionStorage.zip = zip;
    sessionStorage.cruise = cruise;
 
}


function storeCardData(ccnum, cname, expmonth, expyear, cvv) {
    sessionStorage.cname = cname;
	sessionStorage.ccnum = ccnum;
    
    sessionStorage.expmonth = expmonth;
	sessionStorage.expyear = expyear;
    sessionStorage.cvv = cvv;
    
}

function getBookingDetails() {


        document.getElementById("confirm_name").textContent = sessionStorage.fname 
        document.getElementById("c_email").textContent = sessionStorage.email;
		document.getElementById("c_adr").textContent = sessionStorage.adr;
        document.getElementById("c_city").textContent = sessionStorage.city;
        
        document.getElementById("c_state").textContent = sessionStorage.state;
		document.getElementById("c_zip").textContent = sessionStorage.zip;
        document.getElementById("c_cruise").textContent = sessionStorage.productService;
        

    
}

function getCardDetails() {

    
    document.getElementById("confirm_card_name").textContent = sessionStorage.cname;
	document.getElementById("confirm_card_no").textContent = sessionStorage.ccnum;
    document.getElementById("confirm_expmonth").textContent = sessionStorage.expmonth;
	document.getElementById("confirm_expyear").textContent = sessionStorage.expyear;
    document.getElementById("confirm_expyear").textContent = sessionStorage.expyear;
    document.getElementById("confirm_cvv").textContent = sessionStorage.cvv;
}


function myFunction() {
  var dots = document.getElementById("dots");
  var moreText = document.getElementById("more");
  var btnText = document.getElementById("myBtn");

  if (dots.style.display === "none") {
    dots.style.display = "inline";
    btnText.innerHTML = "Read more"; 
    moreText.style.display = "none";
  } else {
    dots.style.display = "none";
    btnText.innerHTML = "Read less"; 
    moreText.style.display = "inline";
  }
}



window.onload = init;

