<!DOCTYPE html>
<html lang="en" id="main_container1">
<head>
     <meta charset="utf-8"/>
    <meta name="keywords" content="HTML5, CSS"/>
    <meta name="author" content="Maisha Maimuna"/>

    <link rel = "stylesheet" type = "text/css" href = "styles/style.css"/>


    <title>Product</title>
    <link rel = "icon" href = 
"images/pro.png"
</head>
<body>

<?php include 'header.inc';?>


<main >
 
    
	
<ul class="c3">
<li >
      <a   href="index.php" id="l1">Back</a>
    </li>
  <li >
      CRUISE SHIP
  </li>
  <li><a class="active" href="index.php">Home</a></li>
  <li><a class="active" href="product.php">Product</a></li>
  <li><a href="card_payment.php">Payment</a></li>
  <li><a href="about.php">About</a></li>
	</ul>	
	
<div style="height:90px;background-color:#07585d;font-size:10px;color: white;">	
	
	
	
</body>
</html>
<p class="ppro">
FREE CANCELLATION BEFORE 1 WEEK!
</p>
<p class="ppro1">
<a href="contact.php">
See returns & cancel policy
</a>
</p>


<div class="page">
	<header>
	<h2>
		Mainstream:
		</h2>
		
		When thinking of a casual Caribbean cruise or a jaunt around the Mexican Riviera, you’re probably picturing something along the lines of a fun-filled Carnival Cruise or family-friendly Royal Caribbean itinerary. These two cruise lines along with a handful of others, are considered your wallet-friendly option with the basics included and the chance to upgrade and purchase a la carte as you choose.
	<br>
	<img src="images/crus1.jpg" class="gridimg" width="500px" height="100px" >
	</header>
	<nav>
		<h2>Luxury: </h2>
		<p>While this might be the most expensive cruise option when you look at the upfront costs, the all-inclusive nature of luxury lines can mean that cruise expenses might not be so far off from the premium options. Silversea, for example, includes flights, pre and post-cruise hotel nights, private transfers, shore excursions on classic voyages, and even butler service. </p>
		<p><a href="https://www.cruisehive.com/category/cruise-news/luxury-cruise-news">Luxury cruises</a> can include mega yachts that fit around 100 people up to mid-sized ships. They have the lowest passenger-to-crew ratios and service is much more personal. Don’t be surprised when you’re greeted by your name as you wander around.

You can expect to be treated as a valued guest while on board with all the comforts and courtesies you’d demand from a five-star resort. Space will be abundant, food is prepared by top chefs, premium drinks are complimentary, and if you do need to ask for anything, you needn’t have to pull out your wallet.
</p>
<br>
<img src="images/c8.jpg" class="gridimg" width=270px height=550px >
	</nav>
	<section>
		<h1>Premium</h1>
		<p>Premium cruise lines cater to travelers looking to explore the world in comfort. They might offer some of the similar activities of the mainstream lines but provide more upscale service and amenities. Think Cunard Line, Celebrity Cruises, Princess Cruises, and Holland America Line.</p>
        <br>
		<img src="images/c5.jpg" class="gridimg" width=600px height=600px>
		<p>Dining options tend to be of a higher caliber and oenophiles should be pleased with regional wine pairings at dinner and a well-thought-out wine list for relaxing on deck. Premium cruises can still be family-friendly but facilities won’t be as extensive as the mainstream ships.</p>
		<p>You also won’t find the droves of thousands onboard these ships, instead, expect to share your traveling home with between 500 and 1,500 guests. This means more room for spacious cabins, public areas designed for easy-going mingling, and decor with a more elegant or conservative touch.</p>
		
	</section>
	<footer>
		<img src="images/c7.jpg" class="gridimg" width=800px height=500px > 
	</footer>
</div>


  



            
			
			
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<p class="abt"> Find me on social media <br>
<a href="https://www.facebook.com/maisha.maimuna.16/" ><img src="images/fb.png" class="ficon"></a>
<a href="https://www.linkedin.com/in/maishamaimuna2/" ><img src="images/li.png" class="ficon"></a></p>
<div class="footer">

<div>
<img src="images/logorem.png" >
</div>
</div>	
<div style="height:90px;background-color:#07585d;font-size:10px;color: white;">		
<footer>
<div class="footertext">
<a  href="https://mik.pte.hu/"> University of Pecs; MIK &copy; </a>
<br>
<strong>Mark up by:</strong> <a href="mailto:maisha.maimuna@pte.hu">
Maisha Maimuna</a>

</footer>
</div>